CONNECT FOUR AI

Files:
- connect_four.py
- requirements.txt
- run_game.bat

How to share on WhatsApp:
1. Put the whole "Connect Four" folder into a zip file.
2. Send the zip file on WhatsApp.
3. Your friend should extract the zip file before running the game.

What your friend needs:
- Python installed
- Internet only the first time, so pygame-ce can be installed automatically

VS Code is NOT required.

How to run:
Option 1:
- Double-click run_game.bat

Option 2:
- Open terminal in this folder and run:
  python -m pip install -r requirements.txt
  python connect_four.py

If Python is not added to PATH:
- Reinstall Python and enable "Add Python to PATH"
- Or run Python from its full installed path
